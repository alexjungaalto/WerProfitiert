"""
WerProfitiert — Wer profitiert von österreichischen Gesetzen?
=============================================================
Konfiguration über drei Textdateien:

  gruppen.txt   — eine Gruppe pro Zeile, z.B.:
                    Bauern
                    Angestellte
                    Immobilien Besitzer

  Zeitraum.txt  — Start- und Endjahr, z.B.:
                    1950 - 1970

  Bericht.txt   — wird vom Skript laufend befüllt (Arbeitsgedächtnis).
                  Jede Zeile = ein BGBl-Gesetz mit Prozentwerten pro Gruppe.
                  Bereits analysierte Gesetze werden übersprungen (Resume).

Verwendung:
    pip install -r requirements.txt
    export ANTHROPIC_API_KEY=sk-ant-...
    python werprofitiert.py
"""

import json
import os
import re
import sys
import time
from datetime import datetime
from html.parser import HTMLParser
from pathlib import Path

import anthropic
import requests
from tqdm import tqdm

# ── Konstanten ─────────────────────────────────────────────────────────────────

MODEL            = "claude-sonnet-4-5"
MAX_TEXT_CHARS   = 6000
RATE_LIMIT_DELAY = 0.5

CONFIG_GRUPPEN  = Path("gruppen.txt")
CONFIG_ZEITRAUM = Path("Zeitraum.txt")
BERICHT         = Path("Bericht.txt")

# ── Konfiguration lesen ────────────────────────────────────────────────────────

def lies_gruppen() -> list[str]:
    if not CONFIG_GRUPPEN.exists():
        sys.exit(
            f"Fehler: '{CONFIG_GRUPPEN}' nicht gefunden.\n"
            "Bitte Datei anlegen, eine Gruppe pro Zeile, z.B.:\n"
            "  Bauern\n  Angestellte\n  Immobilien Besitzer"
        )
    gruppen = [
        line.strip()
        for line in CONFIG_GRUPPEN.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]
    if not gruppen:
        sys.exit(f"Fehler: '{CONFIG_GRUPPEN}' ist leer.")
    return gruppen


def lies_zeitraum() -> tuple[int, int]:
    if not CONFIG_ZEITRAUM.exists():
        sys.exit(
            f"Fehler: '{CONFIG_ZEITRAUM}' nicht gefunden.\n"
            "Bitte Datei anlegen mit Inhalt wie: 1950 - 1970"
        )
    inhalt = CONFIG_ZEITRAUM.read_text(encoding="utf-8").strip()
    zahlen = re.findall(r"\d{4}", inhalt)
    if len(zahlen) < 2:
        sys.exit(
            f"Fehler: '{CONFIG_ZEITRAUM}' konnte nicht gelesen werden.\n"
            f"Inhalt: '{inhalt}'\nErwartet z.B.: 1950 - 1970"
        )
    return int(zahlen[0]), int(zahlen[1])


def lies_bereits_analysiert() -> set[str]:
    """Liest Bericht.txt und gibt BGBl-Nummern zurück die schon fertig sind — für Resume."""
    if not BERICHT.exists():
        return set()
    analysiert = set()
    for line in BERICHT.read_text(encoding="utf-8").splitlines():
        m = re.match(r"^(BGBl\.[^\|]+)\|", line)
        if m:
            analysiert.add(m.group(1).strip())
    return analysiert


# ── RIS API ────────────────────────────────────────────────────────────────────

def ris_suche(jahr: int, seite: int = 1, pro_seite: int = 100) -> dict:
    params = {
        "Applikation":       "BgblAuth",
        "Typ":               "BgblA",
        "ImRisSeit":         "Undefined",
        "DokumenteProSeite": str(pro_seite),
        "Seitenummer":       str(seite),
        "Kundmachungsorgan": f"BGBl. I {jahr}",
    }
    resp = requests.get(
        "https://data.bka.gv.at/ris/api/v2.6/Bundesrecht",
        params=params,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


def hole_gesetzestext(url: str) -> str:
    class TextExtraktor(HTMLParser):
        def __init__(self):
            super().__init__()
            self.teile = []
            self._skip = False

        def handle_starttag(self, tag, attrs):
            if tag in ("script", "style"):
                self._skip = True

        def handle_endtag(self, tag):
            if tag in ("script", "style"):
                self._skip = False

        def handle_data(self, data):
            if not self._skip:
                s = data.strip()
                if s:
                    self.teile.append(s)

    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    ex = TextExtraktor()
    ex.feed(resp.text)
    return " ".join(ex.teile)


def sammle_metadaten(von_jahr: int, bis_jahr: int) -> list[dict]:
    datensaetze = []
    for jahr in range(von_jahr, bis_jahr + 1):
        seite = 1
        jahres_count = 0
        while True:
            try:
                daten = ris_suche(jahr=jahr, seite=seite)
            except requests.RequestException as e:
                print(f"  [Warnung] RIS-Fehler Jahr={jahr} Seite={seite}: {e}")
                break

            treffer = daten.get("OgdSearchResult", {}).get("OgdDocumentResults", {})
            docs = treffer.get("OgdDocumentReference", [])
            if isinstance(docs, dict):
                docs = [docs]
            if not docs:
                break

            for doc in docs:
                meta = doc.get("Data", {}).get("Metadaten", {})
                urls = doc.get("Data", {}).get("Dokumentliste", {}).get("ContentReference", [])
                if isinstance(urls, dict):
                    urls = [urls]

                html_url = next(
                    (u.get("Urls", {}).get("ContentUrl") for u in urls
                     if u.get("ContentType") == "Html"),
                    None,
                )

                datensaetze.append({
                    "jahr":     jahr,
                    "titel":    meta.get("Titel", ""),
                    "bgbl_nr":  meta.get("Kundmachungsorgan", ""),
                    "datum":    meta.get("Kundmachungsdatum", ""),
                    "html_url": html_url,
                })
                jahres_count += 1

            gesamt = int(treffer.get("Hits", {}).get("@anzahl", 0))
            if seite * 100 >= gesamt:
                break
            seite += 1
            time.sleep(RATE_LIMIT_DELAY)

        print(f"  {jahr}: {jahres_count} Gesetze gefunden")

    return datensaetze


# ── LLM-Analyse ───────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """Du bist ein Experte für österreichisches Recht und Sozialpolitik.
Du analysierst Gesetzestexte aus dem Bundesgesetzblatt und bewertest,
wie stark verschiedene gesellschaftliche Gruppen von jedem Gesetz profitieren.
Antworte ausschließlich mit einem gültigen JSON-Objekt, ohne Präambel oder Markdown."""


def erstelle_prompt(titel: str, bgbl_nr: str, datum: str, text: str, gruppen: list[str]) -> str:
    gekuerzt = text[:MAX_TEXT_CHARS] + ("…[gekürzt]" if len(text) > MAX_TEXT_CHARS else "")
    gruppen_json = json.dumps(gruppen, ensure_ascii=False)

    return f"""Analysiere folgenden österreichischen Gesetzestext:

Titel: {titel}
BGBl-Nummer: {bgbl_nr}
Datum: {datum}

Gesetzestext (ggf. gekürzt):
{gekuerzt}

Bewerte für jede der folgenden Gruppen, wie stark sie von diesem Gesetz profitiert.
Gruppen: {gruppen_json}

Antworte mit folgendem JSON:
{{
  "kurzbeschreibung": "1-2 Sätze: Was regelt dieses Gesetz?",
  "gruppen": {{
    "<Gruppenname>": {{
      "prozent": <0-100>,
      "erklaerung": "1 kurzer Satz warum"
    }}
  }}
}}

Regeln für 'prozent':
- 0   = diese Gruppe wird durch das Gesetz nicht berührt
- 1–30  = geringer indirekter Nutzen
- 31–60 = moderater, spürbarer Nutzen
- 61–100 = direkter, starker Nutzen
Die Werte summieren sich NICHT auf 100 — jede Gruppe wird unabhängig bewertet.
Sei differenziert: Die meisten Gesetze betreffen nur 1-3 Gruppen wirklich stark."""


def analysiere_gesetz(client: anthropic.Anthropic, datensatz: dict, gruppen: list[str]) -> dict | None:
    text = ""
    if datensatz.get("html_url"):
        try:
            text = hole_gesetzestext(datensatz["html_url"])
        except Exception as e:
            text = f"[Volltext nicht abrufbar: {e}]"

    prompt = erstelle_prompt(
        titel   = datensatz.get("titel", ""),
        bgbl_nr = datensatz.get("bgbl_nr", ""),
        datum   = datensatz.get("datum", ""),
        text    = text,
        gruppen = gruppen,
    )

    try:
        resp = client.messages.create(
            model      = MODEL,
            max_tokens = 1000,
            system     = SYSTEM_PROMPT,
            messages   = [{"role": "user", "content": prompt}],
        )
        roh = resp.content[0].text.strip()
        if roh.startswith("```"):
            roh = roh.split("```")[1]
            if roh.startswith("json"):
                roh = roh[4:]
        return json.loads(roh)
    except Exception as e:
        print(f"  [LLM-Fehler] {datensatz.get('bgbl_nr', '?')}: {e}")
        return None


# ── Bericht.txt formatieren ───────────────────────────────────────────────────

def formatiere_zeile(datensatz: dict, analyse: dict, gruppen: list[str]) -> str:
    """
    Beispielausgabe:

    BGBl. I 1955/235 | 1955-08-17 | Hausgehilfen- und Hausangestelltengesetz
      Kurzbeschreibung: Regelt erstmals umfassend die Arbeitsbedingungen von Hausangestellten.
      Bauern              :   5% — Kaum betroffen, landwirtschaftliche Haushalte selten beteiligt.
      Angestellte         :  75% — Direkt begünstigt durch Kündigungsschutz und Urlaubsrecht.
      Immobilien Besitzer :  10% — Als potenzielle Arbeitgeber leicht betroffen.
    """
    bgbl   = datensatz.get("bgbl_nr", "?")
    datum  = datensatz.get("datum", "?")
    titel  = datensatz.get("titel", "?")
    beschr = analyse.get("kurzbeschreibung", "")
    ga     = analyse.get("gruppen", {})

    max_len = max((len(g) for g in gruppen), default=10)

    zeilen = [
        f"{bgbl} | {datum} | {titel}",
        f"  Kurzbeschreibung: {beschr}",
    ]
    for gruppe in gruppen:
        info    = ga.get(gruppe, {})
        prozent = info.get("prozent", 0)
        erkl    = info.get("erklaerung", "—")
        pad     = " " * (max_len - len(gruppe))
        zeilen.append(f"  {gruppe}{pad} : {prozent:3d}% — {erkl}")

    zeilen.append("")
    return "\n".join(zeilen)


def initialisiere_bericht(gruppen: list[str], von_jahr: int, bis_jahr: int) -> None:
    header = "\n".join([
        "=" * 72,
        "WerProfitiert — Analysebericht",
        f"Zeitraum : {von_jahr} – {bis_jahr}",
        f"Gruppen  : {', '.join(gruppen)}",
        f"Erstellt : {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        f"Modell   : {MODEL}",
        "=" * 72,
        "",
        "Legende: Prozentwerte sind unabhängig pro Gruppe (summieren nicht auf 100).",
        "         0% = nicht betroffen, 100% = maximaler direkter Nutzen.",
        "",
    ])
    BERICHT.write_text(header, encoding="utf-8")


# ── Hauptprogramm ─────────────────────────────────────────────────────────────

def main():
    gruppen            = lies_gruppen()
    von_jahr, bis_jahr = lies_zeitraum()
    bereits            = lies_bereits_analysiert()

    print(f"\nWerProfitiert")
    print(f"  Zeitraum : {von_jahr} – {bis_jahr}")
    print(f"  Gruppen  : {', '.join(gruppen)}")
    print(f"  Bericht  : {BERICHT}")
    if bereits:
        print(f"  Resume   : {len(bereits)} Gesetze bereits analysiert, werden übersprungen")
    print()

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        sys.exit("Fehler: Umgebungsvariable ANTHROPIC_API_KEY nicht gesetzt.")
    client = anthropic.Anthropic(api_key=api_key)

    print("Schritt 1: Gesetze aus RIS-API laden…")
    alle = sammle_metadaten(von_jahr, bis_jahr)
    print(f"  → {len(alle)} Gesetze gefunden\n")

    # Bericht-Header nur schreiben wenn Datei neu
    if not BERICHT.exists() or not bereits:
        initialisiere_bericht(gruppen, von_jahr, bis_jahr)

    zu_tun = [g for g in alle if g.get("bgbl_nr", "").strip() not in bereits]
    print(f"Schritt 2: {len(zu_tun)} Gesetze analysieren…\n")

    fehler = 0
    for datensatz in tqdm(zu_tun, unit="Gesetz"):
        analyse = analysiere_gesetz(client, datensatz, gruppen)

        if analyse is None:
            fehler += 1
            # Fehler-Platzhalter damit Resume funktioniert
            platzhalter = (
                f"{datensatz.get('bgbl_nr', '?')} | {datensatz.get('datum', '?')} "
                f"| {datensatz.get('titel', '?')}\n"
                f"  [Analysefehler]\n\n"
            )
            with BERICHT.open("a", encoding="utf-8") as f:
                f.write(platzhalter)
        else:
            zeile = formatiere_zeile(datensatz, analyse, gruppen)
            with BERICHT.open("a", encoding="utf-8") as f:
                f.write(zeile + "\n")

        time.sleep(RATE_LIMIT_DELAY)

    print(f"\nFertig!")
    print(f"  Analysiert : {len(zu_tun) - fehler}")
    print(f"  Fehler     : {fehler}")
    print(f"  Bericht    : {BERICHT.resolve()}")


if __name__ == "__main__":
    main()
