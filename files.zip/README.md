# WerProfitiert 🏛️

**Who benefits from Austrian law?**

An open-source LLM agent that crawls the Austrian *Bundesgesetzblatt* (Federal Law Gazette) via the public [RIS API](https://data.bka.gv.at/ris/api/v2.6/), summarises each act, and identifies which groups of people benefited most from postwar Austrian legislation (1945–present).

> *"Wer profitiert?" — the question Austrian politics has always struggled to answer honestly.*

---

## What it does

1. **Crawls** the RIS (Rechtsinformationssystem des Bundes) API for all *Bundesgesetzblatt* entries in a given year range
2. **Fetches** the full text of each act
3. **Analyses** each act using Claude (Anthropic) to extract:
   - A plain-language summary
   - The main beneficiary groups (from a defined taxonomy)
   - Thematic category (Social, Economic, Security, Education…)
   - Political orientation (left / centre / right / unclear)
   - Relevance score (1–5)
4. **Reports** findings as a Markdown document with aggregate statistics by group, decade, and theme

---

## Quickstart

```bash
git clone https://github.com/yourusername/WerProfitiert.git
cd WerProfitiert
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...
```

**Schritt 1** — Gruppen in `gruppen.txt` eintragen (eine pro Zeile):
```
Bauern
Angestellte
Immobilien Besitzer
Mieter
Kirche
```

**Schritt 2** — Zeitraum in `Zeitraum.txt` eintragen:
```
1950 - 1970
```

**Schritt 3** — Skript starten:
```bash
python werprofitiert.py
```

Das Skript befüllt `Bericht.txt` laufend — ein Gesetz pro Eintrag mit Prozentwerten pro Gruppe. Wird das Skript unterbrochen, kann es jederzeit neu gestartet werden und macht dort weiter wo es aufgehört hat (Resume).

**Beispielausgabe in `Bericht.txt`:**
```
BGBl. I 1955/235 | 1955-08-17 | Hausgehilfen- und Hausangestelltengesetz
  Kurzbeschreibung: Regelt erstmals die Arbeitsbedingungen von Hausangestellten.
  Bauern              :   5% — Kaum betroffen, selten Arbeitgeber von Hausangestellten.
  Angestellte         :  75% — Direkt begünstigt durch Kündigungsschutz und Urlaubsrecht.
  Immobilien Besitzer :  10% — Als Arbeitgeber leicht betroffen.
  Mieter              :   0% — Nicht berührt.
  Kirche              :   8% — Kirchliche Haushalte als Arbeitgeber leicht betroffen.
```

---

## Beneficiary taxonomy

Acts are classified against the following groups:

| Group | Description |
|---|---|
| Arbeitnehmer/innen | Employees, wage earners |
| Arbeitgeber / Unternehmen | Employers, businesses |
| Frauen | Women |
| Männer | Men |
| Kinder und Jugendliche | Children and youth |
| Pensionisten/innen | Retirees |
| Landwirte | Farmers |
| Beamte / öffentlich Bedienstete | Civil servants |
| Kirche / religiöse Institutionen | Church, religious bodies |
| Kriegsversehrte / Kriegsheimkehrer | War invalids, returning soldiers |
| Vertriebene / Flüchtlinge | Displaced persons, refugees |
| Migrant/innen / Ausländer/innen | Migrants, foreigners |
| Großunternehmen / Konzerne | Large corporations |
| Klein- und Mittelbetriebe | SMEs |
| Akademiker / Freie Berufe | Academics, liberal professions |
| Wohnungssuchende / Mieter/innen | Renters, housing seekers |
| Hausbesitzer / Vermieter/innen | Property owners, landlords |
| Allgemeine Bevölkerung | General population |
| Keine spezifische Gruppe erkennbar | No specific group identifiable |

---

## Output format

Each analysed act produces a JSON record:

```json
{
  "year": 1955,
  "title": "Bundesgesetz über ...",
  "bgbl_nr": "BGBl. I 1955/125",
  "date": "1955-07-15",
  "html_url": "https://...",
  "analysis": {
    "zusammenfassung": "Dieses Gesetz regelt ...",
    "hauptbeguenstigte": ["Arbeitnehmer/innen", "Pensionisten/innen"],
    "begruendung": "Das Gesetz erweitert ...",
    "politische_ausrichtung": "links",
    "themenbereich": "Soziales",
    "relevanz_score": 4
  },
  "analysed_at": "2026-03-19T10:00:00"
}
```

---

## Data source

All legislation is fetched from the **RIS — Rechtsinformationssystem des Bundes**, the official Austrian legal information system operated by the Federal Chancellery. The API is publicly accessible at `https://data.bka.gv.at/ris/api/v2.6/`.

No login or API key is required to access RIS data.

---

## Limitations and methodology note

- The beneficiary classification is based on LLM inference from act text — it is an approximation, not a legal interpretation.
- Older acts (pre-1980) may have lower-quality text due to OCR from scanned PDFs.
- Political orientation classification is inherently subjective and should be treated as a heuristic, not a verdict.
- The taxonomy covers common groups but is not exhaustive.

Contributions to improve the taxonomy or prompt design are welcome.

---

## Research questions this enables

- Which decade produced the most redistributive legislation?
- Did labor protections peak and then erode? (Sozialpartnerschaft arc)
- When did women shift from "dependents" to explicit beneficiaries in the legal text?
- How did migration-related legislation change in tone post-1989?
- Did church-affiliated groups benefit disproportionately in early postwar legislation?

---

## Contributing

Pull requests welcome. Please open an issue first for substantial changes.

Areas where contributions are especially valuable:
- Improving the beneficiary taxonomy
- Adding OCR support for scanned PDF acts
- Visualisation of results (Plotly / D3)
- Extending to *Landesgesetzblätter* (provincial gazettes)

---

## License

MIT — see [LICENSE](LICENSE)

---

## Author

[Alex Jung](https://github.com/yourusername) — Professor of Machine Learning, Aalto University  
Research interests: federated learning, algorithmic fairness, AI policy

*This project is unaffiliated with any political party or institution.*
